// demo of Starter kit V2.0 - Grove - Light Sensor
// when the value of light sensor ledd than a certain value
// led will on, you can set this certain value via change thresholdvalue
// such as when you cover light sensor with your hand, you'll find led on

const int pinLight = A0;
const int pinLed   = 3;

int outputValue = 0;

void setup()
{
    Serial.begin(9600);
    pinMode(pinLight, INPUT);      
    pinMode(pinLed, OUTPUT);
}

void loop()
{
    int sensorValue = analogRead(pinLight);
    outputValue = map(sensorValue, 0, 1023, 0, 255);
    analogWrite(pinLed, 255-outputValue);

    // envoie tout ça vers l'ordinateur
    Serial.print("sensor = " );                       
    Serial.print(sensorValue);      
    Serial.print("\t output = ");      
    Serial.println(outputValue);
}
