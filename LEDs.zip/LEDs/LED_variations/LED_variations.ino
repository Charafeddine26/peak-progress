// Variable globale qui définit la broche où se trouve la LED
const int LED_TEST = 3;

void setup() {
  // put your setup code here, to run once:
  pinMode(LED_TEST, OUTPUT);
  
}

void loop() {
  // put your main code here, to run repeatedly:
    for(int i=0; i<256; i++)
    {
        analogWrite(LED_TEST, i);
        delay(5);
    }
    delay(100);
    
    for(int i=254; i>=0; i--)
    {
        analogWrite(LED_TEST, i);
        delay(5);
    }
    delay(500);
}
