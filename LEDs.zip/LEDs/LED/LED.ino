// Variable globale qui définit la broche où se trouve la LED
const int LED_TEST = 3;

void setup() {
  // put your setup code here, to run once:
  pinMode(LED_TEST, OUTPUT);
  
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(LED_TEST, HIGH);
  delay(1000);
  digitalWrite(LED_TEST, LOW);
  delay(1000);
}
