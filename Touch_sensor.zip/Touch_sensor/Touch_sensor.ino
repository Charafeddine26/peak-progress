// demo of Grove - Starter V2.0
// Loovee  2013-3-10
// this demo will show you how to use Grove - Button to control a LED
// when the button was pressed, the led will on 
// otherwise led off
// Grove - Button connect to D3
// Grove - LED connect to D7

const int TOUCH_PIN = 3;                    // Broche du bouton
const int LED_PIN = 7;                        // Broche de la LED

void setup()
{
    Serial.begin(9600); // initialise la communication Série
    while (!Serial);    // Attend l'ouverture du port série

    // initialisation
    Serial.println("Initialisation...");
    pinMode(TOUCH_PIN, INPUT);              // set bouton INPUT
    pinMode(LED_PIN, OUTPUT);                 // set led OUTPUT
}

int statutBouton = 0;
int ancienStatutBouton = -1;

void loop()
{
    if(digitalRead(TOUCH_PIN))              // Si bouton appuyé
    {
        statutBouton = 1;
        digitalWrite(LED_PIN, HIGH);
    }
    else
    {
        statutBouton = 0;
        digitalWrite(LED_PIN, LOW);
    }

    if (statutBouton != ancienStatutBouton)
    {
      if (statutBouton)
      {
        Serial.println("Touch détecté !");
        ancienStatutBouton = 1;
      }
      else
      {
        Serial.println("Pas de Touch...");
        ancienStatutBouton = 0;
      }
    }
    
    delay(10);
}
