// demo of Starter Kit V2.0

#include <ChainableLED.h>

#define NUM_LEDS  1

ChainableLED leds(7, 8, NUM_LEDS);
const int potentiometer = A0;                    // rotary angle sensor connect to A0

float hue = 0.0;
int outputValue = 0; 

void setup()
{
    Serial.begin(9600);                         // set the serial communication frequency at 9600 bits per sec
    pinMode(potentiometer, INPUT);
    leds.init();
}

void loop()
{
    int value = analogRead(potentiometer);
    outputValue = map(sensorValue, 0, 1023, 0, 1);
    hue = (float)outputValue;
    leds.setColorHSB(0, hue, 1.0, 0.5);
    Serial.println(value);                      // pirnt the value on the serial monitor screen
    delay(100);                                  // wait 1000ms before printing next value
}
