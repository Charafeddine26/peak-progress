/*
 * Copyright (c) 2016 Intel Corporation.  All rights reserved.
 * See the bottom of this file for the license terms.
 */

/*
   This sketch example demonstrates how the BMI160 on the
   Intel(R) Curie(TM) module can be used to read accelerometer data
   and translate it to an orientation
*/

#include <Arduino_LSM6DS3.h>
#include <ChainableLED.h>

#define NUM_LEDS  1

ChainableLED leds(7, 8, NUM_LEDS);

int lastOrientation = - 1; // previous orientation (for comparison)

void setup() {
  Serial.begin(9600); // initialize Serial communication
  while (!Serial);    // wait for the serial port to open

  // initialize device
  Serial.println("Initializing IMU device...");
  IMU.begin();
  if (!IMU.begin()) {
    Serial.println("Failed to initialize IMU!");

    while (1);
  }

  // initialize LED RGB
  leds.init();
}

void loop() {
  int orientation = - 1;   // the board's orientation
  float x, y, z;
  String orientationString; // string for printing description of orientation
  /*
    The orientations of the board:
    0: flat, processor facing up
    1: flat, processor facing down
    2: landscape, analog pins up
    3: landscape, analog pins down
    4: portrait, USB connector down
    5: portrait, USB connector up
  */
  // read accelerometer:
  if (IMU.accelerationAvailable()) {
    IMU.readAcceleration(x, y, z);
  }

  // calculate the absolute values, to determine the largest
  int absX = abs(x*100);
  int absY = abs(y*100);
  int absZ = abs(z*100);


  if ( (absZ > absX) && (absZ > absY)) {
    // base orientation on Z
    if (z > 0) {
      orientationString = "up";
      orientation = 0; 
      leds.setColorHSB(0, 0.15, 1.0, 0.5); 
    } else {
      orientationString = "down";
      orientation = 1; 
      leds.setColorHSB(0, 0.30, 1.0, 0.5);
    }
  } else if ( (absY > absX) && (absY > absZ)) {
    // base orientation on Y
    if (y > 0) {
      orientationString = "analog pins up";
      orientation = 2; 
      leds.setColorHSB(0, 0.45, 1.0, 0.5);
    } else {
      orientationString = "digital pins up";
      orientation = 3; 
      leds.setColorHSB(0, 0.60, 1.0, 0.5);
    }
  } else {
    // base orientation on X
    if (x < 0) {
      orientationString = "connector down";
      orientation = 4; 
      leds.setColorHSB(0, 0.75, 1.0, 0.5);
    } else {
      orientationString = "connector up";
      orientation = 5; 
      leds.setColorHSB(0, 1.0, 1.0, 0.5);
    }
  }

  // if the orientation has changed, print out a description:
  if (orientation != lastOrientation) {
    Serial.print(x);
    Serial.print('\t');
    Serial.print(y);
    Serial.print('\t');
    Serial.println(z);
    Serial.print(absX);
    Serial.print('\t');
    Serial.print(absY);
    Serial.print('\t');
    Serial.println(absZ);
    Serial.println(orientationString);
    lastOrientation = orientation;
  }
}

/*
   Copyright (c) 2016 Intel Corporation.  All rights reserved.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

*/
