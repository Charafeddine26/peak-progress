// Définition des différentes constantes et des variables globales
const int myLED = 2;
const int myTouch = 4;
// Les deux constantes suivantes sont utilisées pour les fonctions qui détectent si le bouton ou le capteur de touch sont utilisés.
const int touch_appuye = HIGH;
// La variable suivante est utilisée pour la fonction qui détecte si le capteur de touch sont utilisés.
int dernier_etat_touch;
int light = 0;

/*
 * Fonction qui permet de détecter un appui sur le capteur Touch sans effet rebond
 */
int appuiTouch() {
  int etat_touch = digitalRead(myTouch);
  int changement_touch = etat_touch != dernier_etat_touch;
  dernier_etat_touch = etat_touch;
  return changement_touch && (etat_touch==touch_appuye);
}

void setup() {
  // put your setup code here, to run once:
  
  //initialisation des fonctions du bouton et du Touch
  dernier_etat_touch = !touch_appuye;
  
  pinMode(myTouch, INPUT);
  pinMode(myLED, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:

  if (appuiTouch()) {
    if (light == 1) {
      digitalWrite(myLED, LOW);
      light = 0;
    } else {
      digitalWrite(myLED, HIGH);
      light = 1;
    }
  }
      
}
