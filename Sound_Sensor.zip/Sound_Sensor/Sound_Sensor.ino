// demo of Starter Kit V2.0 - Grove Sound Sensor
// when sound larger than a certain value, led will on

const int pinSound = A0;                      // Broche du capteur de son
const int pinLed   = 7;                       // Broche de la LED

int thresholdValue = 200;                     // Seuil de déclanchement de la LED
void setup()
{
    Serial.begin(9600);     
    pinMode(pinLed, OUTPUT);            
}

void loop()
{
    int sensorValue = analogRead(pinSound);   //lecture de sensorValue on Analog 0
    Serial.println(sensorValue); 
    if(sensorValue>thresholdValue)
    digitalWrite(pinLed,HIGH);
    delay(200);
    digitalWrite(pinLed,LOW);
}
