/*
 Controlling a servo position using a potentiometer (variable resistor)
 by Michal Rinott <http://people.interaction-ivrea.it/m.rinott>

 modified on 8 Nov 2013
 by Scott Fitzgerald
 http://www.arduino.cc/en/Tutorial/Knob
*/

#include <Servo.h>

Servo myservo;  // create servo object to control a servo

int potpin = 0;  // analog pin used to connect the potentiometer
int val;    // variable to read the value from the analog pin

void setup()
{
    Serial.begin(9600);                         // set the serial communication frequency at 9600 bits per sec
    while (!Serial)
      delay(10);
    Serial.println("Initialisation");
    pinMode(potpin, INPUT);  
    myservo.attach(5);  // attaches the servo on pin 9 to the servo object
}

void loop()
{
  val = analogRead(potpin);            // reads the value of the potentiometer (value between 0 and 1023)
  Serial.print("valPot = " );                       
  Serial.print(val);      
  val = map(val, 0, 1023, 0, 180);     // scale it to use it with the servo (value between 0 and 180)
  Serial.print("\t angle = ");      
  Serial.println(val);
  myservo.write(val);                  // sets the servo position according to the scaled value$
  delay(15);                           // waits for the servo to get there
}
