// demo of Grove - Starter V2.0
// Loovee  2013-3-10
// this demo will show you how to use Grove - Button to control a LED
// when the button was pressed, the led will on 
// otherwise led off
// Grove - Button connect to D3
// Grove - LED connect to D7

const int PIN_BOUTON = 3;                    // Broche du bouton
const int PINLED = 7;                        // Broche de la LED

void setup()
{
    Serial.begin(9600); // initialise la communication Série
    while (!Serial);    // Attend l'ouverture du port série

    // initialisation
    Serial.println("Initialisation...");
    pinMode(PIN_BOUTON, INPUT);              // set bouton INPUT
    pinMode(PINLED, OUTPUT);                 // set led OUTPUT
}

void loop()
{
    if(digitalRead(PIN_BOUTON))              // Si bouton appuyé
    {
        Serial.print("bouton poussé");
        Serial.println();
        digitalWrite(PINLED, HIGH);
    }
    else
    {
        Serial.print("bouton laché");
        Serial.println();
        digitalWrite(PINLED, LOW);
    }
    
    delay(10);
}
